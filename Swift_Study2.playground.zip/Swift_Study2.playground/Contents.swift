/* Date : 2016.12.04
 * Create : CreateXu
 * File : Swift_Study2
 * Description : Basic
 */

import UIKit

//변수를 선언할 때, var 변수명
//상수를 선언할 때, let 상수명

var year = 1995
var name = "CreateXu"

let date = 1030
let study = "learn"


//let으로 선언된 상수는 수정할 수 없다.

year = 2000
date = 2000

name = "EunXu"
study = "Game"



//선언과 초기화 분리하기

var age : Int
age = 22


//선언과 초기화한 자료형 타입과 같아야한다.

var intV = 1
var strV = "Swift"

//intV = "Swift3"
//strV = 2


//변수와 상수의 이름 정의하기

//알파벳, 한글, 숫자, 특수 기호, 한자, 이모티콘 모두 사용가능

var str1 = "문자"
var int1 = 2
var i_int = 4

var 이름 = "CreateXu"
var ㅅㅇㅍㅌ = "스위프트"
var ㅡㅟㅡㅡ = "스위프트"

var aㅏ = "아"
var 대b = "대박"

var 😀 = "맙소사"
var 弗 = "이게 되네"


//사칙연산, 공백은 사용할 수 없으나 언더바는 가능하다.

//var bbq+bhc = "치킨"
//var hi hello = "인사"
var it_works = "다행"


//스위프트 상에서 키워드로 등록되어 있는 단어는 변수나 상수명에 사용할 수 없다.
//단 대소문자를 바꾸어 사용할 수 있다.


var Class = 1
//var class = 1

var Protocol = 2
//var protocol = 2



//변수, 상수명의 첫번째 자리에 숫자가 올 수 없다.

//var 1first = 1
//let 2second = 2

var f1rst = 1
let s2cond = 2

